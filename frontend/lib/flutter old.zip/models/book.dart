class Book {
  final int? id;
  final String title;
  final String author;
  final double price;

  Book({
    this.id,
    required this.title,
    required this.author,
    required this.price,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    return Book(
      id: json['id'] as int?,
      title: json['title'] as String,
      author: json['author'] as String,
      price: (json['price'] as num).toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      'title': title,
      'author': author,
      'price': price,
    };
  }

  String get description => '$title by $author';
}
