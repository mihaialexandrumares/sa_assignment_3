import 'package:flutter/foundation.dart';
import '../models/book.dart';
import '../services/api_service.dart';

class BookProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  List<Book> _books = [];
  List<String> _featuredBooks = [];
  List<String> _bestsellerBooks = [];
  List<String> _logs = [];
  bool _isLoading = false;
  String? _error;

  List<Book> get books => _books;
  List<String> get featuredBooks => _featuredBooks;
  List<String> get bestsellerBooks => _bestsellerBooks;
  List<String> get logs => _logs;
  bool get isLoading => _isLoading;
  String? get error => _error;

  void _addLog(String message) {
    _logs.add(message);
  }

  void clearLogs() {
    _logs.clear();
    notifyListeners();
  }

  Future<void> loadBooks() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _books = await _apiService.getAllBooks();
      _featuredBooks = await _apiService.getFeaturedBooks();
      _bestsellerBooks = await _apiService.getBestsellerBooks();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addBook(String title, String author, double price) async {
    clearLogs();
    _addLog('[FACADE] LibraryFacade.addBook() called');

    try {
      final book = Book(title: title, author: author, price: price);
      await _apiService.addBook(book);
      _addLog('[FACADE] Book added through facade');
      _addLog('[DECORATOR] Applying FeaturedBookDecorator to display');
      await loadBooks();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteBook(int id) async {
    clearLogs();
    _addLog('[FACADE] LibraryFacade.deleteBook() called');

    try {
      await _apiService.deleteBook(id);
      _addLog('[FACADE] Book deleted through facade');
      await loadBooks();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
    }
  }
}
