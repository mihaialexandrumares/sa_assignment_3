import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/book.dart';

class ApiService {
  // Schimbă cu IP-ul mașinii tale pentru Android Emulator folosește 10.0.2.2
  // Pentru Linux desktop sau browser, folosește localhost
  static const String baseUrl = 'http://localhost:8080/api/books';

  Future<List<Book>> getAllBooks() async {
    final response = await http.get(Uri.parse(baseUrl));
    if (response.statusCode == 200) {
      final List<dynamic> jsonList = json.decode(response.body);
      return jsonList.map((json) => Book.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load books: ${response.statusCode}');
    }
  }

  Future<Book?> getBookById(int id) async {
    final response = await http.get(Uri.parse('$baseUrl/$id'));
    if (response.statusCode == 200) {
      return Book.fromJson(json.decode(response.body));
    }
    return null;
  }

  Future<Book> addBook(Book book) async {
    final response = await http.post(
      Uri.parse(baseUrl),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(book.toJson()),
    );
    if (response.statusCode == 200 || response.statusCode == 201) {
      return Book.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to add book: ${response.statusCode}');
    }
  }

  Future<void> deleteBook(int id) async {
    final response = await http.delete(Uri.parse('$baseUrl/$id'));
    if (response.statusCode != 200 && response.statusCode != 204) {
      throw Exception('Failed to delete book: ${response.statusCode}');
    }
  }

  Future<List<String>> getFeaturedBooks() async {
    final response = await http.get(Uri.parse('$baseUrl/featured'));
    if (response.statusCode == 200) {
      final List<dynamic> jsonList = json.decode(response.body);
      return jsonList.cast<String>();
    } else {
      throw Exception('Failed to load featured books');
    }
  }

  Future<List<String>> getBestsellerBooks() async {
    final response = await http.get(Uri.parse('$baseUrl/bestsellers'));
    if (response.statusCode == 200) {
      final List<dynamic> jsonList = json.decode(response.body);
      return jsonList.cast<String>();
    } else {
      throw Exception('Failed to load bestseller books');
    }
  }
}
