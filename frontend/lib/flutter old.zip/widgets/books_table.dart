import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/book.dart';
import '../services/book_provider.dart';

class BooksTable extends StatelessWidget {
  const BooksTable({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<BookProvider>(
      builder: (context, provider, child) {
        if (provider.books.isEmpty) {
          return const SizedBox.shrink();
        }

        return Card(
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'All Books',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 16),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columns: const [
                      DataColumn(label: Text('ID')),
                      DataColumn(label: Text('Title')),
                      DataColumn(label: Text('Author')),
                      DataColumn(label: Text('Price')),
                      DataColumn(label: Text('Action')),
                    ],
                    rows: provider.books.map((book) => _buildRow(context, book)).toList(),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  DataRow _buildRow(BuildContext context, Book book) {
    return DataRow(
      cells: [
        DataCell(Text(book.id?.toString() ?? '-')),
        DataCell(Text(book.title)),
        DataCell(Text(book.author)),
        DataCell(Text('\$${book.price.toStringAsFixed(2)}')),
        DataCell(
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.red),
            onPressed: () {
              if (book.id != null) {
                Provider.of<BookProvider>(context, listen: false).deleteBook(book.id!);
              }
            },
          ),
        ),
      ],
    );
  }
}
